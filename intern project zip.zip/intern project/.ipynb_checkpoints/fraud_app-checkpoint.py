import streamlit as st
import numpy as np
import joblib
import os

st.title("💳 Fraud Transaction Predictor")

# Load model
model_path = os.path.join(os.path.dirname(__file__), "fraud_model.pkl")
model = joblib.load(model_path)

# Input fields
step = st.number_input("Step (Transaction Time Step)", min_value=0)
type_dict = {"CASH_OUT": 0, "PAYMENT": 1, "CASH_IN": 2, "TRANSFER": 3, "DEBIT": 4}
type_input = st.selectbox("Transaction Type", list(type_dict.keys()))
amount = st.number_input("Transaction Amount", min_value=0.0)
oldbalanceOrg = st.number_input("Old Balance (Sender)", min_value=0.0)
newbalanceOrig = st.number_input("New Balance (Sender)", min_value=0.0)
oldbalanceDest = st.number_input("Old Balance (Receiver)", min_value=0.0)
newbalanceDest = st.number_input("New Balance (Receiver)", min_value=0.0)
isFlaggedFraud = st.selectbox("Is Flagged Fraud", [0, 1])

# Calculate derived features
balanceOrigChange = oldbalanceOrg - newbalanceOrig
balanceDestChange = oldbalanceDest - newbalanceDest

# When Predict button is clicked
if st.button("Predict Fraud"):
    input_data = np.array([[
        step,
        type_dict[type_input],
        amount,
        oldbalanceOrg,
        newbalanceOrig,
        oldbalanceDest,
        newbalanceDest,
        balanceOrigChange,
        balanceDestChange,
        isFlaggedFraud
    ]])

    prediction = model.predict(input_data)

    if prediction[0] == 1:
        st.error("🚨 Alert! This transaction is predicted to be FRAUDULENT.")
    else:
        st.success("✅ This transaction is NOT fraudulent.")





